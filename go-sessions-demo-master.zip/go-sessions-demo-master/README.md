[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)

# Go Session Handling Example

This is a simple "application" to demonstrate the use of the [Gorilla Session](http://www.gorillatoolkit.org/pkg/sessions) package.

Check out the [live demo](https://go-sessions-demo.herokuapp.com/) and [read the docs](https://devcenter.heroku.com/articles/go-sessions).